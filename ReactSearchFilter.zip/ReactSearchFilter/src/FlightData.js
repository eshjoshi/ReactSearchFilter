 const Flights = [{
    "flight_id": "AI-201",
    "source": "Delhi",
    "source_code": "DEL",
    "destination": "Pune",
    "destination_code": "PNQ",
    "fare": "Rs 9500",
    "departs_at": "10:00 AM",
    "arrives_at": "12:00 PM"
}, {
    "flight_id": "AI-207",
    "source": "Kolkata",
    "source_code": "Kol",
    "destination": "Mumbai",
    "destination_code": "Mum",
    "fare": "Rs 6500",
    "departs_at": "10:00 PM",
    "arrives_at": "01:00 AM"
}, {
    "flight_id": "JA-711",
    "source": "Delhi",
    "source_code": "DEL",
    "destination": "Pune",
    "destination_code": "PNQ",
    "fare": "Rs 11500",
    "departs_at": "06:30 AM",
    "arrives_at": "09:00 AM"
}, {
    "flight_id": "JA-517",
    "source": "Kolkata",
    "source_code": "Kol",
    "destination": "Mumbai",
    "destination_code": "Mum",
    "fare": "Rs 6500",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "AI-333",
    "source": "Pune",
    "source_code": "PNQ",
    "destination": "Delhi",
    "destination_code": "DEL",
    "fare": "Rs 9500",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "JA-999",
    "source": "Pune",
    "source_code": "PNQ",
    "destination": "Delhi",
    "destination_code": "DEL",
    "fare": "Rs 11500",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "AI-349",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Delhi",
    "destination_code": "DEL",
    "fare": "Rs 7500",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "JA-909",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Kolkata",
    "destination_code": "KOL",
    "fare": "Rs 12000",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "DA-789",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Kolkata",
    "destination_code": "KOL",
    "fare": "Rs 12000",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "DA-132",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Kolkata",
    "destination_code": "KOL",
    "fare": "Rs 15000",
    "departs_at": "11:00 PM",
    "arrives_at": "1:00 AM"
}, {
    "flight_id": "DA-131",
    "source": "Kolkata",
    "source_code": "KOL",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "07:00 PM",
    "arrives_at": "09:00 AM"
}, {
    "flight_id": "DA-165",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:30 AM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "Ahmedabad",
    "destination": "Mumbai",
    "destination_code": "MUM",
    "fare": "Rs 12000",
    "departs_at": "10:00 PM",
    "arrives_at": "12:00 AM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Chandigarh",
    "destination_code": "CHD",
    "fare": "Rs 12000",
    "departs_at": "05:00 PM",
    "arrives_at": "07:30 AM"
}, {
    "flight_id": "DA-789",
    "source": "Chandigarh",
    "source_code": "CHD",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "11:00 AM",
    "arrives_at": "01:30 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Chennai",
    "destination_code": "CHN",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Chennai",
    "source_code": "CHN",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "03:00 PM",
    "arrives_at": "05:30 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Delhi",
    "destination_code": "DEL",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Delhi",
    "source_code": "DEL",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Hyderabad",
    "source_code": "HYD",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Hyderabad",
    "destination_code": "HYD",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Kolkata",
    "destination_code": "KOL",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Kolkata",
    "source_code": "KOL",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Mumbai",
    "destination_code": "MUM",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Ahmedabad",
    "destination_code": "AHD",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Ahmedabad",
    "source_code": "AHD",
    "destination": "Pune",
    "destination_code": "PUN",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Chennai",
    "destination_code": "CHN",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Chennai",
    "source_code": "CHN",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Chandigarh",
    "destination_code": "CHD",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Chandigarh",
    "source_code": "CHD",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Delhi",
    "destination_code": "DEL",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Delhi",
    "source_code": "DEL",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Hyderabad",
    "destination_code": "HYD",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Hyderabad",
    "source_code": "HYD",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Kolkata",
    "destination_code": "KOL",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Kolkata",
    "source_code": "KOL",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Mumbai",
    "destination_code": "MUM",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Bangalore",
    "source_code": "BLR",
    "destination": "Pune",
    "destination_code": "PUN",
    "fare": "Rs 12000",
    "departs_at": "10:30 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Pune",
    "source_code": "PUN",
    "destination": "Bangalore",
    "destination_code": "BLR",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Pune",
    "source_code": "PUN",
    "destination": "Mumbai",
    "destination_code": "Mum",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Mumbai",
    "source_code": "MUM",
    "destination": "Pune",
    "destination_code": "PUN",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Pune",
    "source_code": "PUN",
    "destination": "Kolkata",
    "destination_code": "KOL",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}, {
    "flight_id": "DA-789",
    "source": "Kolkata",
    "source_code": "KOL",
    "destination": "Pune",
    "destination_code": "PUN",
    "fare": "Rs 12000",
    "departs_at": "9:00 PM",
    "arrives_at": "11:00 PM"
}


];

export default Flights;